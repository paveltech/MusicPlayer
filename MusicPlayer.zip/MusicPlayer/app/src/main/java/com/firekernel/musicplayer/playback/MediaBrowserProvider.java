package com.firekernel.musicplayer.playback;

import android.support.v4.media.MediaBrowserCompat;

public interface MediaBrowserProvider {
    MediaBrowserCompat getMediaBrowser();
}
