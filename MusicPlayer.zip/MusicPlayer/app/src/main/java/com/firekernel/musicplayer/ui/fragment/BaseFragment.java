package com.firekernel.musicplayer.ui.fragment;

import android.support.v4.app.Fragment;

/**
 * Created by Ashish on 5/28/2017.
 */

public class BaseFragment extends Fragment {

}
